first compile the files 
then run as per the instrucitons given