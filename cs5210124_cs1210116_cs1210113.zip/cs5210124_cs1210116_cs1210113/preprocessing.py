import cv2
import numpy as np
import os

np.set_printoptions(linewidth=np.inf, formatter={'float': '{: 0.6f}'.format})

# Function to process each image and save its matrix in a file
def process_image(image_path, output_folder):
    img = cv2.imread(image_path, 0)
    
    if img.shape != (28, 28):
        img = cv2.resize(img, (28, 28))
    
    img = img.reshape(28, 28, -1)
    img = img / 255.0  # Revert the image and normalize it to 0-1 range

    # Get the first 6 characters of the filename
    filename = os.path.splitext(os.path.basename(image_path))[0][:6] + ".txt"
    filepath = os.path.join(output_folder, filename)
    
    # Save matrix to file
    np.savetxt(filepath, img.flatten(), fmt='%0.6f')

# Path to the folder containing images
input_folder = "./img"

# Create output folder if it doesn't exist
output_folder = "./pre-proc-img"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Process each image in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith(".png"):
        image_path = os.path.join(input_folder, filename)
        process_image(image_path, output_folder)

print("Matrices saved successfully.")
