#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<climits>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<vector>
#include<algorithm>
#include <string>  // For std::string and std::atoi
#include <cstdlib> // For std::strtof
using namespace std;





void addPadding(vector<vector<float> >& input, int pad) {
    int originalRows = input.size();
    int originalCols = input[0].size();
    

    for(int i = 0; i < originalRows; i++){
        for(int j = 0; j < pad; j++){
            input[i].insert(input[i].begin(), 0);
            input[i].push_back(0);
        }
    }

    // Adding padding to the columns
    vector<float> padRow(originalCols + 2 * pad, 0);
    for (int i = 0; i < pad; ++i) {
        input.insert(input.begin(), padRow);
        input.push_back(padRow);
    }
}



vector<vector<float> > convolution(vector<vector<float> >& input, vector<vector<float> >& kernel, int pad) {
    if (pad > 0) {
        addPadding(input, pad);
    }

    int inputRows = input.size();
    int inputCols = input[0].size();
    int kernelRows = kernel.size();
    int kernelCols = kernel[0].size();

    // The dimensions of the output matrix
    int outputRows = inputRows - kernelRows + 1;
    int outputCols = inputCols - kernelCols + 1;

    vector<vector<float> > output(outputRows, vector<float>(outputCols, 0));

    // Performing the convolution operation
    for (int i = 0; i < outputRows; ++i) {
        for (int j = 0; j < outputCols; ++j) {
            float sum = 0;
            for (int ki = 0; ki < kernelRows; ++ki) {
                for (int kj = 0; kj < kernelCols; ++kj) {
                    sum += input[i + ki][j + kj] * kernel[ki][kj];
                }
            }
            output[i][j] = sum;
        }
    }

    return output;
}




// Non linear activation 
vector<vector<float> > applyRelu( vector<vector<float> >& matrix) {
    int size = matrix.size();
    vector<vector<float> > output = matrix;

    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            output[i][j] = max(0.0f, matrix[i][j]);
        }
    }

    return output;
}



vector<vector<float> > applyTanh(const vector<vector<float> >& matrix) {
    int size = matrix.size();
    vector<vector<float> > output = matrix;

    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            output[i][j] = tanh(matrix[i][j]);
        }
    }

    return output;
}



// subsampling using max and average pooling
vector<vector<float> > maxPooling( vector<vector<float> >& input, int poolSize) {
    int inputSize = input.size();
    int outputSize = inputSize / poolSize;
    vector<vector<float> > output(outputSize, vector<float>(outputSize, 0));

    for (int i = 0; i < outputSize; ++i) {
        for (int j = 0; j < outputSize; ++j) {
            float maxVal = INT_MIN;
            for (int ki = 0; ki < poolSize; ++ki) {
                for (int kj = 0; kj < poolSize; ++kj) {
                    maxVal = max(maxVal, input[i * poolSize + ki][j * poolSize + kj]);
                }
            }
            output[i][j] = maxVal;
        }
    }

    return output;
}



vector<vector<float> > averagePooling( vector<vector<float> >& input, int poolSize) {
    int inputSize = input.size();
    int outputSize = inputSize / poolSize;
    vector<vector<float> > output(outputSize, vector<float>(outputSize, 0));

    for (int i = 0; i < outputSize; ++i) {
        for (int j = 0; j < outputSize; ++j) {
            float sum = 0;
            for (int ki = 0; ki < poolSize; ++ki) {
                for (int kj = 0; kj < poolSize; ++kj) {
                    sum += input[i * poolSize + ki][j * poolSize + kj];
                }
            }
            output[i][j] = sum / (poolSize * poolSize);
        }
    }

    return output;
}



// vector to probability
vector<float> softmax( vector<float>& input) {
    vector<float> output(input.size());
    float maxVal = *max_element(input.begin(), input.end());
    float sum = 0.0;

    for (size_t i = 0; i < input.size(); ++i) {
        output[i] = exp(input[i] - maxVal);
        sum += output[i];
    }

    for (size_t i = 0; i < input.size(); ++i) {
        output[i] /= sum;
    }

    return output;
}
// why this implementation ? 
// it prevents overflow (and underflow also : when all values are very small) by subtracting the maximum value from each element of the input vector before applying the exponential function.



vector<float> sigmoid( vector<float>& input) {
    vector<float> output(input.size());
    for (size_t i = 0; i < input.size(); ++i) {
        output[i] = 1.0 / (1.0 + exp(-input[i]));
    }
    return output;
}



int main(int argc, char* argv[]) {


    if (argc < 2) {
        cout << "Usage: " << argv[0] << " [task of choice 1=convolution, 2=non-linear-activations, 3=subsampling, 4=converting a vector]" << endl;
        return 1;
    }

    int task = atoi(argv[1]);

    if (task == 1){
        int N = atoi(argv[2]);
        int M = atoi(argv[3]);
        int P = atoi(argv[4]);
        vector<vector<float> > matrix(N, vector<float>(N));
        vector<vector<float> > kernel(M, vector<float>(M));
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                matrix[i][j] = atof(argv[5 + i * N + j]);
            }
        }
        for(int i = 0; i < M; i++){
            for(int j = 0; j < M; j++){
                kernel[i][j] = atof(argv[5 + N * N + i * M + j]);
            }
        }
        vector<vector<float> > output = convolution(matrix, kernel, P);
        for(int i = 0; i < output.size(); i++){
            for(int j = 0; j < output.size(); j++){
                cout << output[i][j] << " ";
            }
            cout << endl;
        }
    }

    if (task == 2){
        int activation = atoi(argv[2]);
        int N = atoi(argv[3]);
        vector<vector<float> > matrix(N, vector<float>(N));
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                matrix[i][j] = atof(argv[4 + i * N + j]);
            }
        }
        vector<vector<float> > output = activation == 0 ? applyRelu(matrix) : applyTanh(matrix); 
        for(int i = 0; i < output.size(); i++){
            for(int j = 0; j < output.size(); j++){
                cout << output[i][j] << " ";
            }
            cout << endl;
        }

    }
    
    if (task == 3){
        int pooling = atoi(argv[2]);
        int M = atoi(argv[3]);
        int N = atoi(argv[4]);
        vector<vector<float> > matrix(N, vector<float>(N));
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                matrix[i][j] = atof(argv[5 + i * N + j]);
            }
        }
        vector<vector<float> > output = pooling == 0 ? maxPooling(matrix, M) : averagePooling(matrix, M);
        for(int i = 0; i < output.size(); i++){
            for(int j = 0; j < output.size(); j++){
                cout << output[i][j] << " ";
            }
            cout << endl;
        }
    }

    if (task == 4){
        int function = atoi(argv[2]);
        int N = argc - 3;
        vector<float> input(N);
        for(int i = 0; i < N; i++){
            input[i] = atof(argv[3 + i]);
        }
        vector<float> output = function == 0 ? sigmoid(input) : softmax(input);
        for(int i = 0; i < output.size(); i++){
            cout << output[i] << " ";
        }
    }

}